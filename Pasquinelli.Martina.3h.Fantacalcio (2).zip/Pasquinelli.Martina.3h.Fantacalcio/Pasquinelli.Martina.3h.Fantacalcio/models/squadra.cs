﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pasquinelli.Martina._3h.Fantacalcio.models
{
    class squadra1
    {
        public string nome { get; set; }
        public string provenienza { get; set; }
        public string icona { get; set; }
        public string sfondo { get; set; }
    }
}