﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pasquinelli.Martina._3h.Fantacalcio.models
{
    class personaggio
    {
        public string nome { get; set; }
        public string ruolo { get; set; }
        public double kill { get; set; }
        public double morti { get; set; }
        public string categoria { get; set; }
        public string icona { get; set; }
        public double score { get; set; }
        public string sfondo { get; set; }
    }
}