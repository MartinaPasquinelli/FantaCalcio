﻿using Pasquinelli.Martina._3h.Fantacalcio.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._3h.Fantacalcio
{
    /// <summary>
    /// Logica di interazione per Eroe.xaml
    /// </summary>
    public partial class Eroe : Window
    {
        personaggio[] amici = new personaggio[14];
        int conta = 0;
        personaggio[] Sq1 = new personaggio[8];
        personaggio[] Sq2 = new personaggio[8];
        public Eroe()
        {
            InitializeComponent();
            for (int i = 0; i < amici.Length; i++)
                amici[i] = new personaggio();

            amici[0].nome = "D.Va";
            amici[1].nome = "Roadhog";
            amici[2].nome = "Reinhart";
            amici[3].nome = "Winston";
            amici[4].nome = "Widowmaker";
            amici[5].nome = "Tracer";
            amici[6].nome = "Geji";
            amici[7].nome = "Junkrat";
            amici[8].nome = "Hanzo";
            amici[9].nome = "Torbjorn";
            amici[10].nome = "Lucio";
            amici[11].nome = "Moira";
            amici[12].nome = "Ana";
            amici[13].nome = "Mercy";

            amici[0].ruolo = "Attacco";
            amici[1].ruolo = "Attacco";
            amici[2].ruolo = "Difesa";
            amici[3].ruolo = "Difesa";
            amici[4].ruolo = "Difesa";
            amici[5].ruolo = "Attacco";
            amici[6].ruolo = "Attacco";
            amici[7].ruolo = "Difesa";
            amici[8].ruolo = "Attacco";
            amici[9].ruolo = "Difesa";
            amici[10].ruolo = "Attacco";
            amici[11].ruolo = "Difesa";
            amici[12].ruolo = "Attacco";
            amici[13].ruolo = "Difesa";

            amici[0].categoria = "Tank";
            amici[1].categoria = "Tank";
            amici[2].categoria = "Tank";
            amici[3].categoria = "Tank";
            amici[4].categoria = "DPS";
            amici[5].categoria = "DPS";
            amici[6].categoria = "DPS";
            amici[7].categoria = "DPS";
            amici[8].categoria = "DPS";
            amici[9].categoria = "DPS";
            amici[10].categoria = "Healer";
            amici[11].categoria = "Healer";
            amici[12].categoria = "Healer";
            amici[13].categoria = "Healer";

            amici[0].icona = "icone/iconadva.png";
            amici[1].icona = "icone/iconaroadhog.png";
            amici[2].icona = "icone/iconareinhardt.png";
            amici[3].icona = "icone/iconawinston.png";
            amici[4].icona = "icone/iconawidowmaker.png";
            amici[5].icona = "icone/iconatracer.png";
            amici[6].icona = "icone/iconagenji.png";
            amici[7].icona = "icone/iconajunkrat.jpg";
            amici[8].icona = "icone/iconahanzo.png";
            amici[9].icona = "icone/iconatorbjorn.png";
            amici[10].icona = "icone/iconalucio.png";
            amici[11].icona = "icone/iconamoira.png";
            amici[12].icona = "icone/iconaana.png";
            amici[13].icona = "icone/iconamercy.png";

            amici[0].sfondo = "sfondi/sfondodva.jpg";
            amici[1].sfondo = "sfondi/sfondoroadhog.jpg";
            amici[2].sfondo = "sfondi/sfondoreinhardt.jpg";
            amici[3].sfondo = "sfondi/sfondowinston.jpg";
            amici[4].sfondo = "sfondi/sfondowidowmaker.jpg";
            amici[5].sfondo = "sfondi/sfondotracer.jpg";
            amici[6].sfondo = "sfondi/sfondogenji.jpg";
            amici[7].sfondo = "sfondi/sfondojunkrat.jpg";
            amici[8].sfondo = "sfondi/sfondohanzo.png";
            amici[9].sfondo = "sfondi/sfondotorbjorn.jpg";
            amici[10].sfondo = "sfondi/sfondolucio.jpg";
            amici[11].sfondo = "sfondi/sfondomoira.jpg";
            amici[12].sfondo = "sfondi/sfondoana.jpg";
            amici[13].sfondo = "sfondi/sfondomercy.png";

        }

        private void modifica(int a)
        {
            bool genio = true;
            for (int i = 0; i < Sq1.Length; i++)
            {
                if (Sq1[i] == amici[a])
                {
                    genio = false; 
                    break;
                }
                if (Sq2[i] == amici[a])
                {
                    genio = false;
                    break;
                }
            }
            if (genio)
            { 
                 sfondo.Source = new BitmapImage(
                  new Uri(amici[a].sfondo, UriKind.RelativeOrAbsolute));
                 nometxt.Text = amici[a].nome;
                 ruolotxt.Text = amici[a].ruolo;
                 categoriatxt.Text = amici[a].categoria;


                if (conta < 8)
                {
                    switch (conta)
                    {
                        case 0:
                            s1.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 1:
                            s2.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 2:
                            s3.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 3:
                            s4.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 4:
                            s5.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 5:
                            s6.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 6:
                            s7.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                        case 7:
                            s8.Source = new BitmapImage(
                                  new Uri(amici[a].icona, UriKind.RelativeOrAbsolute));
                            break;
                    }
                    if (help.Text == "0")
                    {
                            Sq1[conta] = amici[a];               
                    }
                    else
                    {

                        Sq2[conta] = amici[a];
                    }
                    conta++;
                }
            }       
        }

        private void save()
        {
            if(conta==Sq1.Length)
            {
                if (help.Text == "0")
                {
                    StreamWriter fOut = new StreamWriter("datieroi1.txt");
                    for (int i = 0; i < 4; i++)
                    {
                        fOut.WriteLine($"{Sq1[i].nome};{ Sq1[i].icona};{Sq1[i].sfondo};");
                    }
                    fOut.Write($"{Sq1[4].nome};{ Sq1[4].icona};{Sq1[4].sfondo}");
                    fOut.Close();
                    StreamWriter fOut2 = new StreamWriter("datiriserve1.txt");
                    for (int i = 5; i < Sq1.Length-1; i++)
                    {
                        fOut2.WriteLine($"{Sq1[i].nome};{ Sq1[i].icona};{Sq1[i].sfondo};");
                    }
                    fOut2.Write($"{Sq1[7].nome};{ Sq1[7].icona};{Sq1[7].sfondo}");

                    fOut2.Close();
                }
                else if(help.Text == "1")
                {
                    StreamWriter fOut1 = new StreamWriter("datieroi2.txt");
                    for (int i = 0; i < 4; i++)
                    {
                        fOut1.WriteLine($"{Sq2[i].nome};{ Sq2[i].icona};{Sq2[i].sfondo};");
                    }
                    fOut1.Write($"{Sq2[4].nome};{ Sq2[4].icona};{Sq2[4].sfondo}");
                    fOut1.Close();
                
                    StreamWriter fOut3 = new StreamWriter("datiriserve3.txt");
                    for (int i = 5; i < Sq2.Length - 1; i++)
                    {
                        fOut3.WriteLine($"{Sq2[i].nome};{ Sq2[i].icona};{Sq2[i].sfondo};");
                    }
                    fOut3.Write($"{Sq2[7].nome};{ Sq2[7].icona};{Sq2[7].sfondo}");
                    fOut3.Close();
                }
            }
            else
            {
                MessageBox.Show("inseire tutti gli eroi");
            }
        }

        private void ta0_Click(object sender, RoutedEventArgs e)
        {          
            modifica(0);
        }

        private void ta1_Click(object sender, RoutedEventArgs e)
        {
            modifica(1);
        }

        private void ta2_Click(object sender, RoutedEventArgs e)
        {
            modifica(2);
        }

        private void ta3_Click(object sender, RoutedEventArgs e)
        {
            modifica(3);
        }

        private void sp0_Click(object sender, RoutedEventArgs e)
        {
            modifica(10);
        }

        private void sp1_Click(object sender, RoutedEventArgs e)
        {
            modifica(11);
        }

        private void sp2_Click(object sender, RoutedEventArgs e)
        {
            modifica(12);
        }

        private void sp3_Click(object sender, RoutedEventArgs e)
        {
            modifica(13);
        }

        private void dp0_Click(object sender, RoutedEventArgs e)
        {
            modifica(4);
        }

        private void dp1_Click(object sender, RoutedEventArgs e)
        {
            modifica(5);
        }

        private void dp2_Click(object sender, RoutedEventArgs e)
        {
            modifica(6);
        }

        private void dp3_Click(object sender, RoutedEventArgs e)
        {
            modifica(7);
        }

        private void dp4_Click(object sender, RoutedEventArgs e)
        {
            modifica(8); ;
        }

        private void dp5_Click(object sender, RoutedEventArgs e)
        {
            modifica(9);
        }

        private void ex_Click(object sender, RoutedEventArgs e)
        {
            if (conta ==Sq1.Length)
            {
                this.Close();
                save();
            }
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {

            this.Close();
        }
    }
}
