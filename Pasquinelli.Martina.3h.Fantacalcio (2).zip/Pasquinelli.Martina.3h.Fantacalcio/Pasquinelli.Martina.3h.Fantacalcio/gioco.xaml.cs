﻿using Pasquinelli.Martina._3h.Fantacalcio.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._3h.Fantacalcio
{
    /// <summary>
    /// Logica di interazione per gioco.xaml
    /// </summary>
    public partial class gioco : Window
    {
        bool apposto = true;
        string nome;
        string riga;
        int conta = 0;
        int conta1 = 0;
        string[] split = new string[5];
        string riga1;
        string[] split1 = new string[5];
        string[] riservesp = new string[3];
        string rigaris;
        personaggio[] eroig1 = new personaggio[5];
        personaggio[] eroig2 = new personaggio[5];
        personaggio[] riserve1 = new personaggio[3];
        personaggio[] riserve2 = new personaggio[3];
        public gioco()
        {

            InitializeComponent();

            for (int i = 0; i < eroig1.Length; i++)
            {
                eroig2[i] = new personaggio();
                eroig1[i] = new personaggio();
             
            }
            for (int i = 0; i < riserve1.Length; i++)
            {
                riserve1[i] = new personaggio();
                riserve2[i] = new personaggio();
            }

        }

        private void leggi()
        {

                StreamReader fIn = new StreamReader("datieroi1.txt");
                while (((riga = fIn.ReadLine()) != null) && (conta < 6))
                {
                    split[conta] = riga;
                    string[] aiuto = split[conta].Split(';');
                    eroig1[conta].nome = aiuto[0];
                    eroig1[conta].icona = aiuto[1];
                    eroig1[conta].sfondo = aiuto[2];

                    conta++;
                }
                fIn.Close();

                StreamReader fIn2 = new StreamReader("datieroi2.txt");
                while ((riga1 = fIn2.ReadLine()) != null)
                {
                    split1[conta1] = riga1;
                    string[] aiuto1 = split1[conta1].Split(';');
                    eroig2[conta1].nome = aiuto1[0];
                    eroig2[conta1].icona = aiuto1[1];
                    eroig2[conta1].sfondo = aiuto1[2];

                    conta1++;
                }
                fIn.Close();

                conta = 0;
                StreamReader fIn3 = new StreamReader("datiriserve1.txt");
                while ((rigaris = fIn3.ReadLine()) != null)
                {
                    riservesp[conta] = rigaris;
                    string[] aiuto2 = riservesp[conta].Split(';');
                    riserve1[conta].nome = aiuto2[0];
                    riserve1[conta].icona = aiuto2[1];
                    riserve1[conta].sfondo = aiuto2[2];

                    conta++;
                }
                fIn3.Close();

                conta = 0;
                StreamReader fIn4 = new StreamReader("datiriserve3.txt");
                while ((rigaris = fIn4.ReadLine()) != null)
                {
                    riservesp[conta] = rigaris;
                    string[] aiuto3 = riservesp[conta].Split(';');
                    riserve2[conta].nome = aiuto3[0];
                    riserve2[conta].icona = aiuto3[1];
                    riserve2[conta].sfondo = aiuto3[2];

                    conta++;
                }
                fIn4.Close();

                StreamWriter fio = new StreamWriter("aiutatemi.txt");
                fio.WriteLine(tx.Text);
                fio.Close();

                dg1.ItemsSource = eroig1;
                dg2.ItemsSource = eroig2;


        }
        private void randomkill()
        {
            double[] morti = new double[5];
            double[] morti1 = new double[5];
            
            Random rnd2 = new Random();
            for (int i = 0; i < eroig1.Length; i++)
            {
                    morti[i] = rnd2.Next(0, 21);
                    eroig1[i].kill = morti[i];
            }
            for (int i = 0; i < eroig2.Length; i++)
            {
 
                    morti1[i] = rnd2.Next(0, 21);
                    eroig2[i].kill = morti1[i];
            }
            int[] idx = new int[5];
            for (int i = 0; i < idx.Length; i++)
            {
                idx[i] = rnd2.Next(0, 5);
                for (int j = 0; j < idx.Length; j++)
                {
                    if (j != i)
                    {
                        if (idx[i] == idx[j])
                        {
                            i--;
                            j = 5;
                        }
                    }
                }
            }
            for (int i = 0; i < eroig2.Length; i++)
            {
                    eroig2[i].morti = morti[idx[i]];
            }
            int[] idx2 = new int[5];
            for (int i = 0; i < idx2.Length; i++)
            {
                idx2[i] = rnd2.Next(0, 5);
                for (int j = 0; j < idx2.Length; j++)
                {
                    if (j != i)
                    {
                        if (idx2[i] == idx2[j])
                        {
                            i--;
                            j = 5;
                        }
                    }
                }
            }
            for (int i = 0; i < eroig1.Length; i++)
            {
                    eroig1[i].morti = morti1[idx2[i]];
            }
            
        }
        private void Score()
        {
            double somma1 = 0, somma2 = 0;
            for (int i = 0; i < eroig1.Length; i++)
            {
                if (eroig1[i].morti == 0)
                {
                    eroig1[i].score = eroig1[i].kill;
                    somma1 = somma1 + eroig1[i].score;
                }
                else
                {
                    eroig1[i].score = Math.Round(eroig1[i].kill / eroig1[i].morti, 2);
                    eroig2[i].score = Math.Round(eroig2[i].kill / eroig2[i].morti, 2);
                    somma1 = somma1 + eroig1[i].score;
                    somma2 = somma2 + eroig2[i].score;
                }
                if (eroig2[i].morti == 0)
                {
                    eroig2[i].score = eroig2[i].kill;
                    somma2 = somma2 + eroig2[i].score;
                }
                else
                {
                    eroig1[i].score = Math.Round(eroig1[i].kill / eroig1[i].morti, 2);
                    eroig2[i].score = Math.Round(eroig2[i].kill / eroig2[i].morti, 2);
                    somma1 = somma1 + eroig1[i].score;
                    somma2 = somma2 + eroig2[i].score;
                }
            }
            if (somma1 > somma2)
            {
                tx.Text = Convert.ToString("1");
                tx1.Text = Convert.ToString("0");
            }
            else
            {
                tx.Text = Convert.ToString("0");
                tx1.Text = Convert.ToString("1");
            }
            double max=0;
            int index=0;
            for (int i = 0; i < eroig1.Length; i++)
            {
                if (max < eroig1[i].score)
                {
                    max = eroig1[i].score;
                    index = i;
                }
            }
            StreamWriter mazx = new StreamWriter("migliorgiocatore.txt");
            mazx.WriteLine(eroig1[index].sfondo);
            mazx.Close();

        }
        private void win()
        {
            if (tx.Text == "1")
            {
                StreamReader f1 = new StreamReader("Ngiocatore1.txt");
                nome = f1.ReadLine();
                f1.Close();
            }
            else
            {
                StreamReader f1 = new StreamReader("Ngiocatore2.txt");
                nome = f1.ReadLine();
                f1.Close();
            }
        } 

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            win();
            MessageBox.Show("ha vinto: " + nome);
            this.Close();
        }

        private void Button_Click_GO(object sender, RoutedEventArgs e)
        {
            if (apposto)
            {
                randomkill();
                Score();
                leggi();
                apposto = false;
            }
        }
    }
}
