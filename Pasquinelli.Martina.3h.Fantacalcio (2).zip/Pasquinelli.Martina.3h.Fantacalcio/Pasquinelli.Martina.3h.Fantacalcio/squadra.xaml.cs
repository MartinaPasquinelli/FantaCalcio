﻿using Pasquinelli.Martina._3h.Fantacalcio.models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._3h.Fantacalcio
{
    /// <summary>
    /// Logica di interazione per squadra.xaml
    /// </summary>
    public partial class squadra : Window
    {
        squadra1[] ciao = new squadra1[7];
        squadra1 sqplayer1 = new squadra1();
        string save1,save2;
        
        int conta;
        public squadra()
        {
            InitializeComponent();
            for(int i = 0; i < ciao.Length; i++)
            {
                ciao[i] = new squadra1();
            }
            ciao[0].sfondo = "https://www.powned.it/wp-content/uploads/2017/11/florida-mayhem-650x325.jpg";
            ciao[1].sfondo = "https://cdn-images-1.medium.com/max/1600/1*X-0RdFd5huooQdvYWi5CiA.png";
            ciao[2].sfondo = "https://bnetcmsus-a.akamaihd.net/cms/gallery/vm/VMWZ5JQNR6BW1508896415184.jpg";
            ciao[3].sfondo = "https://bnetcmsus-a.akamaihd.net/cms/gallery/M42Y9H65IJVU1509428106162.jpg";
            ciao[4].sfondo = "https://bnetcmsus-a.akamaihd.net/cms/gallery/SBNT3DBW78ZK1509426568594.jpg";
            ciao[5].sfondo = "https://www.powned.it/wp-content/uploads/2017/10/seoul-dynasty-1.jpg";
            ciao[6].sfondo = "https://bnetcmsus-a.akamaihd.net/cms/gallery/M5B8EFZ2GC011509475482766.jpg";

            ciao[0].icona = "iconesq/mayhem.jpg";
            ciao[1].icona = "iconesq/excelsior.jpg";
            ciao[2].icona = "iconesq/uprising.jpg";
            ciao[3].icona = "iconesq/fusior.jpg";
            ciao[4].icona = "iconesq/spitfire.jpg";
            ciao[5].icona = "iconesq/dynasty.jpg";
            ciao[6].icona = "iconesq/gladiators.jpg";

            ciao[0].nome = "Mayhem";
            ciao[1].nome = "Excelsior";
            ciao[2].nome = "Uprising";
            ciao[3].nome = "Fusion";
            ciao[4].nome = "Spitfire";
            ciao[5].nome = "Dynasty";
            ciao[6].nome = "Gladiators";

            ciao[0].provenienza = "Florida";
            ciao[1].provenienza = "New York";
            ciao[2].provenienza = "Boston";
            ciao[3].provenienza = "Philadelphia";
            ciao[4].provenienza = "London";
            ciao[5].provenienza = "Seul";
            ciao[6].provenienza = "Los Anegeles";

        }
        private void modifica(int a)
        {
           img.Source = new BitmapImage(
                  new Uri(ciao[a].sfondo, UriKind.RelativeOrAbsolute));
            nomesq.Text = ciao[a].nome;
            citta.Text = ciao[a].provenienza;
            if (helps.Text == "0")
            {
                save1=ciao[a].icona;
            }
            else
            {
                save2=ciao[a].icona;

            }
            sqplayer1 = ciao[a];
                conta++;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            modifica(0);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            modifica(1);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            modifica(2);

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            modifica(3);

        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            modifica(4);

        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            modifica(5);

        }

        private void Button_Click_6(object sender, RoutedEventArgs e)
        {
            modifica(6);

        }

        private void Button_Click_end(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Click_done(object sender, RoutedEventArgs e)
        {
            if (helps.Text == "0")
            {
                StreamWriter squadra = new StreamWriter("datisquadra1.txt");
                squadra.WriteLine(save1);
                squadra.Close();
            }
            else
            {
                StreamWriter squadra1 = new StreamWriter("datisquadra2.txt");
                squadra1.WriteLine(save2);
                squadra1.Close();
            }
            this.Close();
        }
    }
}
