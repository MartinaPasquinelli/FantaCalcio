﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Pasquinelli.Martina._3h.Fantacalcio
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Eroe fin1 = new Eroe();
        squadra fin2 = new squadra();
        Eroe fin3 = new Eroe();
        squadra fin4 = new squadra();
        gioco fin5 = new gioco();
        int conta = 0;
        public MainWindow()
        {
            InitializeComponent();

        }

        private void fep1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                fin1.help.Text = "0";
                fin1.ShowDialog();
                conta++;
            }
            catch
            {
            }
        }

        private void fsp1_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                fin2.helps.Text = "0";
                fin2.ShowDialog();

                conta++;
            }
            catch
            {

            }
        }

        private void fep2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                fin3.help.Text = "1";
                fin3.ShowDialog();

                conta++;
            }
            catch
            {

            }

        }

        private void fsp2_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                fin4.helps.Text = "1";
                fin4.ShowDialog();
                conta++;
            }
            catch
            {

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (conta == 4)
            {
                StreamReader fI = new StreamReader("datisquadra1.txt");
                string riga5 = fI.ReadLine();
                fin5.sq1img.Source = new BitmapImage(
                      new Uri(riga5, UriKind.RelativeOrAbsolute));
                fI.Close();

                StreamReader fn = new StreamReader("datisquadra2.txt");
                string riga6 = fn.ReadLine();
                fin5.sq2img.Source = new BitmapImage(
                      new Uri(riga6, UriKind.RelativeOrAbsolute));
                fn.Close();

                StreamWriter f1 = new StreamWriter("Ngiocatore1.txt");
                f1.WriteLine(ng1.Text);
                f1.Close();
                StreamWriter f2 = new StreamWriter("Ngiocatore2.txt");
                f2.WriteLine(ng2.Text);
                f2.Close();

                fin5.help2.Text = "4";
                try
                {
                    fin5.ShowDialog();
                    this.Close();
                }
                catch
                {

                }
            }
            else
            {
                MessageBox.Show("Inserire tutti i dati");
            }
        }
    }
}
